import type { APIRoute } from 'astro';
import projects from '../content/projects.json';
export const GET: APIRoute = ({ site }) => {
  const base = import.meta.env.BASE_URL.replace(/\/$/, '');
  const routes = ['', 'resume/', ...projects.map(p => `projects/${p.slug}/`)];
  const urls = site ? routes.map(route => `<url><loc>${new URL(`${base}/${route}`, site).href}</loc></url>`).join('') : '';
  return new Response(`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${urls}</urlset>`, { headers: { 'Content-Type': 'application/xml' } });
};
