export const path = (relative = '') => `${import.meta.env.BASE_URL.replace(/\/$/, '')}/${relative.replace(/^\//, '')}`;
