import { defineConfig } from 'astro/config';

// SITE_URL is the full deployment URL, including a repository subpath when needed.
// Unset for local builds: canonical, sitemap and social URL metadata are omitted.
const deployment = process.env.SITE_URL ? new URL(process.env.SITE_URL) : undefined;
if (deployment && deployment.protocol !== 'https:') throw new Error('SITE_URL must use HTTPS.');
export default defineConfig({
  output: 'static',
  site: deployment?.origin,
  base: deployment?.pathname.replace(/\/$/, '') || '/',
  trailingSlash: 'always',
  build: { format: 'directory' },
  devToolbar: { enabled: false },
});
