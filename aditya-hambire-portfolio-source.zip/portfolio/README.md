# Aditya Hambire portfolio

A static Astro + TypeScript portfolio with ordinary CSS and progressive hero entrances, section reveals and a desktop scroll showcase. No backend, visitor login, AI service, database, third-party fonts, analytics or cookies are configured.

## Windows installation and preview

Install Node.js 24 LTS from https://nodejs.org/ (the project requires at least Node 22.22). In PowerShell, change into the extracted `portfolio` folder, then run:

```powershell
npm install --global pnpm@11.25.0
pnpm install --frozen-lockfile
pnpm run check
pnpm run build
pnpm run preview
```

Open the Local URL printed in the terminal, normally http://127.0.0.1:4321/. If that port is occupied, Astro prints a different port. Keep the terminal open; Ctrl+C stops the foreground server. If an agent starts a background preview, `node scripts/astro.mjs preview stop` stops it. For editable development use `pnpm run dev`.

No server runs on a visitor's computer after deployment. GitHub Pages serves the generated HTML, CSS, JavaScript and approved assets.

## What to edit

| File | Purpose |
| --- | --- |
| `src/content/home.json` | Concise homepage introduction, project summaries and additional-work descriptions |
| `src/content/profile.json` | Introduction, contact links, education, experience, leadership and additional work |
| `src/content/projects.json` | Featured projects, case-study text, status, contribution, methods and optional real resource links |
| `src/content/certificates.json` | Real, reviewed certificate entries; an empty array hides the gallery |
| `src/styles/global.css` | Colour, typography, spacing, responsive layout and reduced motion |
| `scripts/generate-assets.py` | Public PDF rÃ©sumÃ© and text-based social preview |
| `public-files.json` | Exact allowlist of files that may be copied from `public/` |
| `source-files.json` | Exact allowlist for the source ZIP |

Edit existing project fields in JSON. `slug` controls the route; keep it lowercase and hyphenated. A project resource is `{ "label": "Source code", "url": "https://â€¦" }` in its `links` array. Add a link only after verifying that it is the correct public project. Empty link arrays produce no buttons. New entries create case-study routes and sitemap entries. Set homepage order in src/pages/index.astro and add its short summary to home.json.

The rÃ©sumÃ© PDF uses concise curated text in `scripts/generate-assets.py`; changing project JSON does not automatically rewrite that PDF. Update its curated text when project facts change. To regenerate it:

```powershell
py -m pip install reportlab pypdf Pillow
py scripts/generate-assets.py
pnpm run build
```

Inspect the new PDF visually, extract its text, check its links and metadata, and approve it before deployment. Never replace it with an uploaded original CV.

## Adding certificates

1. Keep originals outside this repository. Check all text, signatures, identifiers, QR codes, links and metadata. Create a permanently sanitised PNG/WebP/JPEG preview; covering text with a removable overlay is insufficient. Keep an accessible, sanitised PDF only when needed.
2. Put the reviewed derivatives in `public/certificates/`. Add each exact relative filename to `public-files.json`, then to `source-files.json` with the `public/` prefix.
3. Add a real entry to `src/content/certificates.json`. Supported fields: `id`, `title`, `issuer`, `category`, optional `date`, `preview` (relative to `public/`), numeric `width` and `height`, meaningful `alt`, and optional `document` (PDF path). Categories are exactly `Participation`, `Completion`, `Award`, `Internship`, or `Research acceptance`. Use only confirmed dates and titles. Never use an acceptance certificate to imply publication.
4. Run `pnpm run check` and `pnpm run build`. Inspect the certificate at desktop and phone widths. Tab to its preview summary, open with Enter or Space, and close using the same control. Native `<details>` works without JavaScript. Images reserve dimensions and lazy-load. Check PDF accessibility separately if supplied.

No demo certificates or placeholder entries are included.

## Adding project screenshots

Publish only reviewed, sanitised derivatives of real screenshots. Remove private pixels and metadata permanently. Prefer WebP at the required display size. Add filenames to both allowlists; render with meaningful alt text, explicit width/height and `loading="lazy"` below the fold. The existing project graphics are custom inline SVG workflow illustrations, not screenshots or measured results.

## Privacy and packaging

`public/` is copied into the site, so never put original documents, notes, credentials, screenshots awaiting review or secrets there. The public-asset allowlist rejects unexpected or missing files. The post-build audit checks allowed routes/assets, page metadata, email boundaries, source maps and private-source references. A human must still inspect the pixels and content of any newly approved asset.

Only `adhambire@gmail.com`, the supplied GitHub profile and the supplied LinkedIn profile are published contact details. Source files are public if the repository is public. Keep private notes outside the repository entirely.

From the source folder, `py scripts/package.py --output ..` creates the source ZIP and static ZIP from explicit allowlists, excluding dependencies, caches, `.git`, secrets and private originals. Build and review first. Update `source-files.json` intentionally when adding source files.

## Deployment

See `DEPLOYMENT.md`. Local builds omit canonical/social URL tags and emit an empty sitemap URL set until `SITE_URL` is configured. Deployment builds derive that URL from the GitHub repository or an explicit repository variable, so canonical URLs, social image URLs, internal links and sitemap paths agree.


## Current certificate gallery

Nine privacy-redacted documents are supplied in three groups. Edit certificates.json fields: group, category, date, preview (full WebP), thumbnail (small WebP), width, height, alt and companion. The startup documents are companion records of one programme. Do not infer employment from the Deloitte/Forage job simulation or institutional affiliation from a logo.

The gallery links work without JavaScript. With JavaScript, a native modal opens the full image on demand. Tab moves among controls; arrow keys move between documents; Escape closes and restores focus. Add both images to both allowlists. Render and permanently redact signatures, QR/verification codes and sensitive details before adding files. Never publish original certificate PDFs or the SOP.

## Hero typography

Edit the hero paragraph and contact headline in src/pages/index.astro. HeroName.astro contains the accessible name, decorative letters and bounded pointer effect. The final block of global.css controls its size, layered shadows and entrance timings. Reduced motion and no-JavaScript visitors see the static heading; touch devices omit pointer tilt.
