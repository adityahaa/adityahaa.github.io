"""Create public derivatives only from the approved portfolio content.
Requires Python 3.10+, reportlab, pypdf and Pillow. Run from the project root.
The supplied brief and original documents are never read by this script.
"""
from pathlib import Path
import io, json
from xml.sax.saxutils import escape
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph
from pypdf import PdfReader, PdfWriter
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent.parent
profile = json.loads((ROOT/'src/content/profile.json').read_text(encoding='utf-8'))
INK='#282b26'; OLIVE='#56613f'; MUTED='#555b50'
buffer=io.BytesIO()
c=canvas.Canvas(buffer, pagesize=(595.276,841.89), invariant=1)
left=43; width=509; y=798
body=ParagraphStyle('body',fontName='Helvetica',fontSize=9.3,leading=12.5,textColor=HexColor(INK))
def para(text, gap=6):
    global y
    p=Paragraph(text,body); _,h=p.wrap(width,750)
    p.drawOn(c,left,y-h);y-=h+gap
def section(title):
    global y
    y-=8
    c.setStrokeColor(HexColor('#c9cbbd'));c.setLineWidth(.5);c.line(left,y,left+width,y)
    y-=18;c.setFillColor(HexColor(OLIVE));c.setFont('Helvetica-Bold',9)
    c.drawString(left,y,title.upper());y-=15
c.setFillColor(HexColor(INK));c.setFont('Times-Roman',31);c.drawString(left,y,'Aditya Hambire');y-=24
para(escape(profile['intro']),8)
para('<link href="mailto:adhambire@gmail.com" color="#56613f">adhambire@gmail.com</link>  |  <link href="https://github.com/adityahaa" color="#56613f">github.com/adityahaa</link>  |  <link href="https://www.linkedin.com/in/aditya-hambire/" color="#56613f">LinkedIn</link>',1)
section('Education')
para('<b>K. J. Somaiya Institute of Technology</b> | 2023-2027<br/>B.Tech in Artificial Intelligence and Data Science; Cybersecurity honours.<br/>Additional coursework in Innovation &amp; Entrepreneurship.',2)
section('Selected projects')
para('<b>Cause2Cure | Team research project</b><br/>Contributed to a causal ML research project and its dashboard and manuscript, exploring drug effectiveness across patient populations. Conference accepted and presented; proceedings publication accepted and in progress with Springer Nature.',8)
para('<b>SupplySense | Individual project, developed with AI coding assistance</b><br/>Built a local forecasting and inventory-planning application using public M5 data, chronological evaluation, seasonal baselines, gradient boosting and a Streamlit dashboard. Inventory outcomes are simulations, not real business savings.',8)
para('<b>ProductSense | Individual project, developed with AI coding assistance</b><br/>Built a local feedback-to-PRD workflow using Python, LangGraph and Gemini, with human approval, evidence links, review, saved edits and Markdown/Word exports. A small live trial demonstrated feasibility; broader quality evaluation remains pending.',8)
para('<b>LastMile | Team mobility prototype</b><br/>Contributed to the mobility prototype and business planning, exploring ride matching, fixed pricing and a proposed revenue model. Under incubation at K. J. Somaiya Institute of Technology; not an operating ride service.',1)
section('Experience')
para('<b>Defence Technology Intern | BSERC | 2026</b><br/>Completed a defence and space summer internship programme with AI/ML learning and a CNN-based Indian Sign Language recognition project.',7)
para('<b>CAD Workshop Instructor | 10-week workshop</b><br/>Taught CAD fundamentals to school students through practical activities.',1)
section('Leadership')
para('<b>Institutional Lead, National Entrepreneurship Challenge, E-Cell IIT Bombay:</b> Led college-level participation as the institutional representative.<br/><b>Campus Ambassador, E-Cell IIT Bombay:</b> Represented the college in an entrepreneurship initiative.<br/><b>Student Coordinator Head, Green Club:</b> Progressed from membership to student coordination leadership.',1)
section('Selected skills')
para('Python, Java, Flask, Streamlit, machine learning, causal ML, RAG, LangGraph, data visualisation, business-model development and technical communication.',0)
if y < 37: raise RuntimeError('Resume overflows one page; shorten content before regenerating.')
c.showPage();c.save()
reader=PdfReader(buffer);writer=PdfWriter();writer.append_pages_from_reader(reader)
writer.add_metadata({'/Title':'Aditya Hambire - Public Resume','/Author':'Aditya Hambire','/Subject':'Education, projects, experience and leadership','/Creator':'Public portfolio resume generator','/Producer':'Public portfolio'})
out=ROOT/'public/downloads/aditya-hambire-resume.pdf';out.parent.mkdir(parents=True,exist_ok=True)
with out.open('wb') as f:writer.write(f)

def font(size, serif=False):
    choices = [Path('C:/Windows/Fonts/georgia.ttf' if serif else 'C:/Windows/Fonts/arial.ttf'), Path('/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf' if serif else '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')]
    for p in choices:
        if p.exists():return ImageFont.truetype(str(p),size)
    return ImageFont.load_default(size=size)
im=Image.new('RGB',(1200,630),'#f5f3ec');d=ImageDraw.Draw(im)
d.text((70,55),'AI & DATA SCIENCE  /  PRODUCT  /  ENTREPRENEURSHIP',font=font(18),fill=OLIVE)
d.line((70,106,1130,106),fill='#c9cbbd',width=2)
d.text((64,175),'Aditya Hambire.',font=font(100,True),fill=INK)
d.text((70,335),'Building practical products.',font=font(39,True),fill=OLIVE)
d.text((70,460),'Research, forecasting, product workflows and mobility.',font=font(24),fill=INK)
d.line((70,548,1130,548),fill='#c9cbbd',width=2)
d.text((70,571),'SELECTED WORK & PROFESSIONAL PROFILE',font=font(16),fill=MUTED)
im.save(ROOT/'public/assets/social-preview.png',optimize=True)
print(f'Created public resume: 1 page, bottom margin {y:.1f} pt. Social preview: 1200 x 630.')
