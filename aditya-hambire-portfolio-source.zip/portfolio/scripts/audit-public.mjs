import { readdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
export function files(directory, prefix = '') {
  return readdirSync(directory, { withFileTypes: true }).flatMap(entry => {
    if (entry.isSymbolicLink()) throw new Error('Symbolic links are not permitted in public assets.');
    const relative = prefix + entry.name;
    return entry.isDirectory() ? files(join(directory, entry.name), relative + '/') : [relative];
  });
}
const allowlist = JSON.parse(readFileSync('public-files.json', 'utf8'));
const actual = files('public');
if (new Set(allowlist).size !== allowlist.length || allowlist.some(p => p.includes('..') || p.startsWith('/'))) throw new Error('Invalid public asset allowlist.');
if (actual.length !== allowlist.length || actual.some(p => !allowlist.includes(p))) throw new Error('Public asset allowlist mismatch. Review added or missing files before building.');
const certificates = JSON.parse(readFileSync('src/content/certificates.json', 'utf8'));
const categories = ['Participation', 'Completion', 'Award', 'Internship', 'Research acceptance'];
const ids = new Set();
for (const c of certificates) {
  if (!c.id || ids.has(c.id) || !c.title || !c.issuer || !categories.includes(c.category) || !c.alt || !(c.width > 0 && c.height > 0) || !allowlist.includes(c.preview) || !/\.(png|webp|jpg)$/.test(c.preview) || (c.document && (!allowlist.includes(c.document) || !c.document.endsWith('.pdf')))) throw new Error('Invalid certificate content or unapproved assets.');
  if (c.thumbnail && (!allowlist.includes(c.thumbnail) || !/\.(png|webp|jpg)$/.test(c.thumbnail))) throw new Error('Unapproved certificate thumbnail.');
  ids.add(c.id);
}
console.log(`Public allowlist passed: ${actual.length} approved assets; ${certificates.length} certificate entries.`);
