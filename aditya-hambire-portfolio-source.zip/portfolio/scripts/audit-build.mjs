import { readFileSync, statSync } from 'node:fs';
import { files } from './audit-public.mjs';
const allowed = JSON.parse(readFileSync('public-files.json', 'utf8'));
const projects = JSON.parse(readFileSync('src/content/projects.json', 'utf8'));
const expected = ['index.html', 'resume/index.html', '404.html', 'robots.txt', 'sitemap.xml', 'projects/rag-document-chatbot/index.html', ...projects.map(p => `projects/${p.slug}/index.html`), ...allowed];
const output = files('dist');
const errors = [];
if (expected.some(p => !output.includes(p))) errors.push('A required page or asset is absent.');
for (const file of output) {
  if (!expected.includes(file) && !/^_astro\/[\w.-]+\.(css|js)$/.test(file)) errors.push('Unapproved file in static output.');
  if (/\.(html|xml|txt|js|css|svg)$/.test(file)) {
    const text = readFileSync(`dist/${file}`, 'utf8');
    const emails = text.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi) || [];
    if (emails.some(e => e !== 'adhambire@gmail.com')) errors.push('Unapproved email in static output.');
    if (/file:\/\/|C:\\Users\\|Portfolio_Brief|PRIVATE_NOTES|sourceMappingURL|\b(?:CGPA|TOEFL|IELTS|transcript|date of birth)\b/i.test(text)) errors.push('Potential private source reference in static output.');
    if (file.endsWith('.html') && (!text.includes('<title>') || !text.includes('name="description"') || !text.includes('class="skip-link"'))) errors.push('Missing page metadata or skip navigation.');
  }
}
if (errors.length) throw new Error([...new Set(errors)].join('\n'));
const bytes = output.reduce((n,f) => n + statSync(`dist/${f}`).size, 0);
console.log(`Static output audit passed: ${output.length} files, ${bytes} bytes. No private originals or source maps included.`);
