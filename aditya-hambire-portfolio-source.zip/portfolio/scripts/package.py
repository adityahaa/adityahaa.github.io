"""Package only explicitly approved source and static output. Standard library only."""
from pathlib import Path
import argparse,hashlib,json,zipfile
ROOT=Path(__file__).resolve().parent.parent
p=argparse.ArgumentParser();p.add_argument('--output',default='..');args=p.parse_args()
target=Path(args.output).resolve();target.mkdir(parents=True,exist_ok=True)
manifest=json.loads((ROOT/'source-files.json').read_text(encoding='utf-8'))
if len(manifest)!=len(set(manifest)):raise RuntimeError('Duplicate source entries')
def approved(path,root):
    file=(root/path).resolve()
    if not file.is_relative_to(root) or not file.is_file() or file.is_symlink():raise RuntimeError('Invalid approved file')
    return file
with zipfile.ZipFile(target/'aditya-hambire-portfolio-source.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for entry in manifest:z.write(approved(entry,ROOT),f'portfolio/{entry}')
assets=json.loads((ROOT/'public-files.json').read_text(encoding='utf-8'))
projects=json.loads((ROOT/'src/content/projects.json').read_text(encoding='utf-8'))
pages=['index.html','resume/index.html','404.html','robots.txt','sitemap.xml']+[f"projects/{v['slug']}/index.html" for v in projects]
dist=ROOT/'dist';names=[p.relative_to(dist).as_posix() for p in dist.rglob('*') if p.is_file()]
for name in names:
    if name not in pages+assets and not (name.startswith('_astro/') and Path(name).suffix in ['.js','.css'] and len(Path(name).parts)==2):raise RuntimeError('Unapproved build output')
with zipfile.ZipFile(target/'aditya-hambire-portfolio-static.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name in names:z.write(approved(name,dist),name)
checksums={name:hashlib.sha256((target/name).read_bytes()).hexdigest() for name in ['aditya-hambire-portfolio-source.zip','aditya-hambire-portfolio-static.zip']}
(target/'checksums.json').write_text(json.dumps(checksums,indent=2)+'\n',encoding='utf-8')
print(f'Packaged {len(manifest)} approved source files and {len(names)} static files.')
