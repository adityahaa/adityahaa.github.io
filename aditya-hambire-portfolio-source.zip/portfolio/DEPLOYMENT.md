# Free GitHub Pages deployment

Prepared on 22 October 2026. Nothing has been pushed or published.

The proposed target is a public repository named `adityahaa.github.io` under the supplied GitHub account, producing the expected URL `https://adityahaa.github.io/`. This is an intended destination, not a verified live deployment. A repository lookup returned 404; existence and write access must be rechecked before creation or publication.

GitHub Pages is available for public repositories on GitHub Free. Use the included `github.io` address and no paid domain or service. See [GitHub Pages availability](https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages) and [Astro's official GitHub Pages guide](https://docs.astro.build/en/guides/deploy/github/). Action versions follow the official Astro guide checked on the preparation date.

## After owner approval

1. Create a public GitHub repository named `adityahaa.github.io` only after confirming it does not already exist. If it exists, inspect and preserve its content before proceeding. Do not overwrite an existing site.
2. Upload/push only the approved source archive contents. Do not push the enclosing task folder, `work/`, private notes, original documents, `node_modules/`, `.astro/` or `dist/`. `source-files.json` defines the reviewed source set.
3. In repository **Settings → Pages → Build and deployment**, choose **GitHub Actions** as the source.
4. In **Actions → Deploy portfolio to GitHub Pages**, select **Run workflow** on `main`. The workflow is manual; later pushes do not silently publish.
5. Wait for both build and deploy jobs to succeed. Open the deployment URL from the job, verify the homepage, each case study, résumé download, canonical tags, social image, sitemap and a missing route. Only then record the verified public URL in the handoff.

If creating/pushing manually, run in the extracted `portfolio` directory after approval:

```powershell
git init -b main
$approvedFiles = Get-Content -Raw source-files.json | ConvertFrom-Json
foreach ($approvedFile in $approvedFiles) { git add -- $approvedFile }
git status --short
git commit -m "Add professional portfolio"
git remote add origin https://github.com/adityahaa/adityahaa.github.io.git
git push -u origin main
```

Use a GitHub no-reply email for the commit author if configured locally; do not expose an unapproved personal email in public commit metadata. Authentication may require signing into GitHub. The repository must exist before `git push`.

## Deployment-aware local test

For the proposed root site:

```powershell
$env:SITE_URL = 'https://adityahaa.github.io/'
pnpm run build
pnpm run preview
```

For a project repository, set the full URL including the repository path, for example `https://adityahaa.github.io/portfolio/`. The code handles that base path automatically. A custom HTTPS domain can be supplied through the repository variable `SITE_URL`; custom DNS setup is not included or needed.

To return to a local-only build:

```powershell
Remove-Item Env:SITE_URL -ErrorAction SilentlyContinue
pnpm run build
```

The source ZIP contains the workflow and build configuration. The static ZIP contains only generated files and approved public assets; it can also be served by another static host with the matching `SITE_URL` rebuild.
